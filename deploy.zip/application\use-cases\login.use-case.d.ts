export declare class LoginUseCase {
    execute(): void;
}
