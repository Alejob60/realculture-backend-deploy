"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AppDataSource = void 0;
const typeorm_1 = require("typeorm");
const user_entity_1 = require("./domain/entities/user.entity");
const content_entity_1 = require("./domain/entities/content.entity");
exports.AppDataSource = new typeorm_1.DataSource({
    type: 'postgres',
    host: 'localhost',
    port: 5432,
    username: 'postgres',
    password: 'postgres',
    database: 'realculture',
    synchronize: false,
    logging: false,
    entities: [user_entity_1.UserEntity, content_entity_1.Content],
    migrations: ['src/migrations/*.ts'],
});
//# sourceMappingURL=data-source.js.map