import { Content } from './content.entity';
export declare class Creator {
    id: string;
    name: string;
    bio: string;
    avatarUrl: string;
    contents: Content[];
}
