import { UserEntity } from './user.entity';
export declare class GeneratedMusicEntity {
    id: string;
    userId: string;
    user: UserEntity;
    musicUrl: string;
    prompt: string;
    createdAt: Date;
}
