export declare enum UserRole {
    FREE = "FREE",
    CREATOR = "CREATOR",
    PRO = "PRO"
}
