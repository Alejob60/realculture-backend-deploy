export declare class AzureBlobModule {
}
