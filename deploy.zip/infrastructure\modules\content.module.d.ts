export declare class ContentModule {
}
