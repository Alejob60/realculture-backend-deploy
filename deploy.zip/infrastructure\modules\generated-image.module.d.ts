export declare class GeneratedImageModule {
}
