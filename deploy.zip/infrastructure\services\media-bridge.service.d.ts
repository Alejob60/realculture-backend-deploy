import { HttpService } from '@nestjs/axios';
import { Request } from 'express';
export declare class MediaBridgeService {
    private readonly httpService;
    private readonly logger;
    private readonly generatorUrl;
    private readonly VIDEO_SERVICE_URL;
    constructor(httpService: HttpService);
    private buildHeaders;
    generatePromoImage(data: {
        prompt: string;
        plan: string;
        textOverlay?: string;
    }): Promise<any>;
    generateVideo(data: any, token?: string): Promise<unknown>;
    generateVoice(data: any, token?: string): Promise<unknown>;
    generateMusic(data: any, token?: string): Promise<unknown>;
    generateAgent(data: any, token?: string): Promise<unknown>;
    generateSubtitles(data: any, token?: string): Promise<unknown>;
    generateAvatar(data: any, token?: string): Promise<unknown>;
    generateCampaign(data: any, token?: string): Promise<unknown>;
    fetchAudioFile(filename: string): Promise<Buffer>;
    forward(endpoint: string, req: Request, payload: any): Promise<any>;
}
