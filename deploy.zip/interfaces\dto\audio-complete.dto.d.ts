export declare class AudioCompleteDto {
    userId: string;
    prompt: string;
    audioUrl: string;
    duration: number;
}
