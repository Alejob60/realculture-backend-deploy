export declare class CreateCreatorDto {
    name: string;
    email: string;
    password: string;
}
