export declare class CreateGeneratedImageDto {
    userId: string;
    prompt: string;
    imageUrl: string;
}
