export declare class GenerateAudioDto {
    prompt: string;
    duration?: string;
}
