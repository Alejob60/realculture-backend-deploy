export declare class GeneratePromoImageDto {
    prompt: string;
    textOverlay?: string;
}
