export declare class GoogleLoginDto {
    token: string;
}
