"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GoogleLoginDto = void 0;
class GoogleLoginDto {
    token;
}
exports.GoogleLoginDto = GoogleLoginDto;
//# sourceMappingURL=google-login.dto.js.map