export declare class LoginRequestDto {
    email: string;
    password: string;
}
