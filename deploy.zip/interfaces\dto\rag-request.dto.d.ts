export declare class RagRequestDto {
    prompt: string;
}
