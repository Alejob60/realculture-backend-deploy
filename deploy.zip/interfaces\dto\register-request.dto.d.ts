export declare class RegisterRequestDto {
    name: string;
    email: string;
    password: string;
}
