export declare class VideoGenerationDto {
    image: Express.Multer.File;
    text: string;
}
