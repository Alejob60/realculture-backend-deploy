"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.VideoGenerationDto = void 0;
class VideoGenerationDto {
    image;
    text;
}
exports.VideoGenerationDto = VideoGenerationDto;
//# sourceMappingURL=video-generation.dto.js.map