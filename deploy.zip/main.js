"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const core_1 = require("@nestjs/core");
const app_module_1 = require("./app.module");
const typeorm_1 = require("typeorm");
const helmet_1 = require("helmet");
const express_rate_limit_1 = require("express-rate-limit");
const dotenv = require("dotenv");
const path_1 = require("path");
const cookieParser = require("cookie-parser");
async function bootstrap() {
    dotenv.config();
    const app = await core_1.NestFactory.create(app_module_1.AppModule);
    app.use((0, helmet_1.default)());
    app.enableCors({
        origin: ['http://localhost:3000'],
        methods: 'GET,POST,PUT,PATCH,DELETE,OPTIONS',
        credentials: true,
        allowedHeaders: ['Content-Type', 'Authorization'],
    });
    app.use(cookieParser());
    app.use((0, express_rate_limit_1.default)({
        windowMs: 15 * 60 * 1000,
        max: 100,
        message: '⚠️ Demasiadas solicitudes. Intenta nuevamente en unos minutos.',
    }));
    app.useStaticAssets((0, path_1.join)(__dirname, '..', 'public'));
    const dataSource = app.get(typeorm_1.DataSource);
    if (dataSource.isInitialized) {
        console.log('✅ Conexión a la base de datos establecida correctamente.');
    }
    else {
        console.error('❌ Fallo al conectar a la base de datos.');
    }
    await app.listen(process.env.PORT || 3001);
    console.log(`🚀 Backend listo en http://localhost:${process.env.PORT || 3001}`);
}
bootstrap();
//# sourceMappingURL=main.js.map